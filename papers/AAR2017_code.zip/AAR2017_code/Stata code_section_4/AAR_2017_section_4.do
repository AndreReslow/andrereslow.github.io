******************************************************************************************************
* This script produces the results in Section 4 of the paper: 
* Adjusting for Information Content when Comparing Forecast Preformance
* Journal of Forecasting, 36, 784-794
* by: Andersson, Aranki & Reslow (2017)
*
*
*******************************************Important**************************************************

clear all
set more off
set obs 1	

scalar ivar=1				/*1==GDP, 2==CPI, */	/*Choose variable*/

/*Set evaluation sample, AAR: 1999-2015*/
scalar start_year=1999
scalar end_year=2015

*****************************************************************************	
                            *** load data ***
*****************************************************************************	
 
if  ivar==1 {
	use GDP.dta, clear        
	}
else if ivar==2 {
	use CPI.dta, clear
	}
	
/*
Some data explaination:
date = day of forecats publication
name = forecast institute
xxx_forecast = forecast
actual_xxx = outcome
fe = forecast error
afe = absolute forecast error
year = forecast origin year
forcyear = forecast target year
horizon = months to end of forecast target year
*/
	
	drop if forcyear < start_year
	drop if forcyear > end_year
	
	*** replace horizon with accumulated weight W ***
		gen W = .
replace W = 143/144 if horizon ==1
replace W = 141/144 if horizon ==2
replace W = 138/144 if horizon ==3
replace W = 134/144 if horizon ==4
replace W = 129/144 if horizon ==5
replace W = 123/144 if horizon ==6
replace W = 116/144 if horizon ==7
replace W = 108/144 if horizon ==8
replace W = 99/144 if horizon ==9
replace W = 89/144 if horizon ==10
replace W = 78/144 if horizon ==11
replace W = 66/144 if horizon ==12
replace W = 55/144 if horizon ==13
replace W = 45/144 if horizon ==14
replace W = 36/144 if horizon ==15
replace W = 28/144 if horizon ==16
replace W = 21/144 if horizon ==17
replace W = 15/144 if horizon ==18
replace W = 10/144 if horizon ==19
replace W = 6/144 if horizon ==20
replace W = 3/144 if horizon ==21
replace W = 1/144 if horizon ==22
replace W = 0/144 if horizon ==23
replace W = 0/144 if horizon ==24

gen M = 1 - W 	


*****************************************************************************	
	                          *** Table 3 ***
*****************************************************************************	
sort name date year forcyear
table (name), c(N afe mean afe sd afe min afe max afe)
xtsum afe, i(name)
table (name), c(mean horizon)
xtsum horizon, i(name)

*****************************************************************************	
	                      *** Table 4 Panel A ***
*****************************************************************************	
xi:areg afe M i.forcyear, absorb(name) robust
testparm _Iforcyear_*, equal
xi:reg afe M i.forcyear MoF HUI SN NIER LO NDA RB SEB SHB SWED, noconst robust
testparm MoF HUI SN NIER LO NDA RB SEB SHB SWED, equal
xi:reg afe c.M#i.name i.forcyear, robust
testparm name#c.M, equal

*****************************************************************************	
	                      *** Table 4 Panel B ***
*****************************************************************************	
xi:areg afe c.M#forcyear i.forcyear, absorb(name) robust
testparm _Iforcyear_*, equal
xi:reg afe c.M#forcyear i.forcyear MoF HUI SN NIER LO NDA RB SEB SHB SWED, noconst robust
testparm MoF HUI SN NIER LO NDA RB SEB SHB SWED, equal
testparm forcyear#c.M, equal

*****************************************************************************	
	                        *** Figure 3 ***
*****************************************************************************		
xi:areg afe M i.forcyear, absorb(name) robust
gen delta = _b[M]*M
scatter afe horizon || line delta horizon, sort 

*****************************************************************************	
	                        *** Figure 4 ***
*****************************************************************************		
xi:areg afe c.M#forcyear i.forcyear, absorb(name) robust
predict ind, d
collapse (mean) ind afe, by(name)
egen grand_mean = mean(ind)	
egen grand_mean_afe = mean(afe)	
by name: gen adjmae= ind - grand_mean
by name: gen mae= afe - grand_mean_afe
table name, c(mean adjmae mean mae) 
graph bar adjmae mae, over(name, sort(adjmae))




