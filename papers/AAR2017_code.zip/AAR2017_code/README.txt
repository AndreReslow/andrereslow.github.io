README

Article: 
Adjusting for Information Content when Comparing Forecast Performance
Journal of Forecasting, 36, 784-794

By: Andersson, Aranki & Reslow

-----------------------------------------------------------------------------------
Section 3: Monte Carlo Simulation
-----------------------------------------------------------------------------------
Simulations performed using MATLAB (Version 8.1.0.604, The MathWorks Inc., Natick, Massachusetts, USA)

The Matlab code Main.m runs a loop over all the lines in table 2 (+ some more). Note that the runtime
on this is very long! To reduce runtime you could lower the number of simulations(S)

The below Matlab scrips need to be in the work path to run the Main.m file: 
Loop_spec.m  - Setting simulation values in the loop, from Table 2.
gen_random.m - Generate random ability
get_ref2.m   - Calculate M
Est.m 	     - Estimate ability 

The code also have a file called Extra.m, this file enables running simulations not 
using the loop.

-----------------------------------------------------------------------------------
Section 4: Empirical Application 
-----------------------------------------------------------------------------------
Replicate the results by running the Stata code AAR_2016_section_4.do
Data files: GDP.dta & CPI.dta
Data also attached in Excel format


