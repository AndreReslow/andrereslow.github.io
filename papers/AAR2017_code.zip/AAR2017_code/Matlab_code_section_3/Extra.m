


clear; close all; clc

rng('default') % default seed for random number generator

%% Spec

c = 2;            % Case: 1 (A=...=G), 2 (A>...>G), 3 (A<...<G), 4 random
N = 1;            % years in ability sample
sigma = 0.30;     % std in error term
mu = 0.02;        % Ability signal
a = 0.8;          % "Own effekt"

S = 100000;       % number of simulations

Hmax = 24;      % monthly data = 24, quarterly = 8
fig = 1;        % plot if 1
%%
% Publishing calendar
H = [1 1 0 0 0 0 0;0 0 1 1 0 1 0;1 0 0 0 1 0 0;0 1 1 0 0 0 1;0 0 0 1 1 0 0;1 0 0 0 0 0 1;0 1 0 0 0 1 0;0 0 1 1 0 0 0;
     0 0 0 0 1 1 0;1 1 1 0 0 0 1;0 0 0 1 1 0 0;0 0 0 0 0 1 1;1 1 0 0 0 0 0;0 0 1 1 0 1 0;1 0 0 0 1 0 0;0 1 1 0 0 0 1;
     0 0 0 1 1 0 0;1 0 0 0 0 0 1;0 1 0 0 0 1 0;0 0 1 1 0 0 0;0 0 0 0 1 1 0;1 1 1 0 0 0 1;0 0 0 1 1 0 0;0 0 0 0 0 1 1];
H(H==0)= NaN;

% Individual ability
ind = 0:mu:mu*6; 
switch c
    case 1
        ind = 0*ind;        % Equal ability (A=...=G)
    case 2
        ind = fliplr(ind);  % A worst, G best, (A>...>G)
    case 3
        ind = ind;          % A best, G worst, (A<...<G)
    case 4
        gen_random;         % run random ability generator   
end
%%
% generate ref line
[M, L] = get_ref2(Hmax, a);

if fig == 1;
figure(1)
plot(1:Hmax, [M L])
legend('Outcome effect','Out. + Own effect.', 'Location','SouthEast' )
title('Normalized expected forecast error')
xlabel('Forecast horizon') 
end

for ii = 1:S
    if c == 3
        ind = Sind(ii,:);
    end
% draw forecast error
 for i = 1:N
    for j = 1:length(ind)
     for jj = 1:Hmax
      fe(jj,j,i) =  (L(jj) + ind(j) + abs(sigma*randn(1))) ;
     end
    end
    Ind_FE(:,:,i) = fe(:,:,i).*H ;
 end

for i = 1:N
    for j = 1:length(ind)
temp = Ind_FE(:,j,i);
temp = temp(~isnan(temp));
FE(:,j,i) = temp; 
    end
end

 % Calculate regulare MAE
temp = []; mae = [];
for i = 1:N   
temp = FE(:,:,i);
mae = [mae; temp];
end
MAE(ii,:) = mean(mae);

beta =  Est(FE,H,M);  % Estimate ability
B(:,ii) = beta;         % save
end

IND = B(N*2:end,:)' ; % take out ability from estimation

% for each simulation, rank individuals based on estimation and MAE
for i = 1:S
[~, idxA] = sort(IND(i,:)) ;
[~, idxB] = sort(MAE(i,:)) ; 
indexA(i,:) = idxA;
indexB(i,:) = idxB;
end

%%
% Get observed and expected frequency:
if c ==1
   for i = 1:7  
    O = hist(indexA(:,i),1:7);
    OA(i,:) = O; 
    E(i,:) = ones(1,7).*(S/7);
    Ob = hist(indexB(:,i),1:7);
    OB(i,:) = Ob;
   end
end

if c ==2
   for i = 1:7  
    O = hist(indexA(:,i),1:7);
    OA(i,:) = O; 
    E(i,:) = zeros(1,7);
    E(i,8-i) = S;
    Ob = hist(indexB(:,i),1:7);
    OB(i,:) = Ob;
   end
end

if c ==3
   for i = 1:7  
    O = hist(indexA(:,i),1:7);
    OA(i,:) = O; 
    E(i,:) = zeros(1,7);
    E(i,i) = S;
    Ob = hist(indexB(:,i),1:7);
    OB(i,:) = Ob;
   end
end

if c ==4
   for i = 1:7  
    O = hist(indexA(:,i),1:7);
    OA(i,:) = O; 
    Ob = hist(indexB(:,i),1:7);
    OB(i,:) = Ob;
    E(i,:) = hist(Erank(:,i),1:7);
   end
end

%% rho
if c == 1
    rho= zeros(7,7);
end

if c == 2
    for i = 1:7
        for r = 1:7
            j=8-i;
    rho(r,i) = abs(j-r);
        end
    end
end

if c == 3
    for i = 1:7
        for r = 1:7
    rho(r,i) = abs(i-r);
        end
    end
end

if c == 4
    rho= zeros(7,7);
end

%% MIR

MIR_a = sqrt(sum(sum(((OA - E).^2).*((1+rho).^2)))/49)/S;
MIR_b = sqrt(sum(sum(((OB - E).^2).*((1+rho).^2)))/49)/S;


 %%
 mycmp =  [  
    0       0       0
    0.40    0.40    0.40
    0.51    0.51    0.51
    0.62    0.62    0.62
    0.73    0.73    0.73
    0.84    0.84    0.84
    0.95    0.95    0.95
    1       1       1    ];
 
if fig == 1;
figure(2)
bar(OA/S,'stacked')
colormap(mycmp)
set(gca,'FontName','cmr12')
legend('A','B','C','D','E','F','G','location','northeastoutside')
xlabel('Ranking position')
ylabel('Frequency share')
ylim([0 1])
title('Adjusted mean absolute error')

figure(3)
bar(OB/S,'stacked')
colormap(mycmp)
set(gca,'FontName','cmr12')
legend('A','B','C','D','E','F','G','location','northeastoutside')
xlabel('Ranking position')
ylabel('Frequency share')
ylim([0 1])
title('Mean absolute error')
end

