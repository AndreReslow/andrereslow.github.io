function [ FE_comp, FE_compAR] = get_ref2(Hmax, a)

%Hmax =24; % 24 if monthly, 8 if quarterly 
%a = 0.3;


% Horizon weights - the weight each month have in the full year outcome (y/y) 
w=zeros(1,Hmax);
for h = 1:Hmax
    if h<(Hmax/2)+1
    w(h)=h/((Hmax/2)^2);    
    else
    w(h)=(Hmax-h)/((Hmax/2)^2);  
    end
end
%% Computational effect - this is the accumulated weight known in each horizon
comp = zeros(Hmax,1);
for h = 1:Hmax-1  
comp(h,1) = sum(w(h+1:Hmax)); % sum the weigths at each h, +1 since we do not know contemporary outcomes
end

%% AR effect - the series have some persistence a - this give us info about the future weights
az =zeros(Hmax,1);
for h = 1:Hmax
  az(h,1) = a^h;
end

ar=zeros(Hmax,1);
for h = 1:Hmax % at each horison we know some about each future outcome
    ar(h,1) =  sum(az(h:-1:1).*w(1:h)'); % sum the AR components at each h
end


%% Norm fe effects
FE_comp = 1 - comp; % Normalized absolute forecast error given by 1 - accum. weights
FE_compAR = 1 - (comp + ar); % combined effect of computational and AR effects


end



 