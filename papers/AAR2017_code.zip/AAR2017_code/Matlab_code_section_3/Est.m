function [beta, X, Y] = Est(FE,H,trend)
% FE - [Number of forecast, number of individuals , number of years]
% H - horizon matrix
% trend - trend vector 
% we do not do withinestimation in the MC simulation - since this do not affect
% the rankings

[h,ind,n] = size(FE);
t = repmat(trend,1,ind).*H;
t = t(~isnan(t));

T = zeros(h*ind*n,n);
C = zeros(h*ind*n,n);
s=1;
e=h*ind;
for i = 1:n
T(s:e,i) = t;  
C(s:e,i) = ones(h*ind,1);   
s=s + h*ind;
e=e + h*ind;    
end
Dum = zeros(h*ind,ind);
s=1;
e=h;
for i = 1:ind
Dum(s:e,i) = ones(h,1) ;   
s= s+h;
e= e+h;
end
Y = [];
D = [];
for i = 1:n  
vec =   FE(:,:,i); 
Y = [Y ; vec(:)];
D = [D ; Dum];
end
X = [C(:,1:n-1) T D];
beta  = regress(Y,X);
end

