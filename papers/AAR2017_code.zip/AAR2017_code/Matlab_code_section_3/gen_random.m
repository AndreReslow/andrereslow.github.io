
% Draw random abilities 
LL=0.16; % = mu*6/(6/8)

for i = 1:S
t=0;
while t==0
x = rand(7,1).*LL;
t = isequal(length(x), length(unique(x)));   
end
ind = x';
[~,eb] = sort(ind);
Sind(i,:) = ind;
Erank(i,:) = eb;
end
