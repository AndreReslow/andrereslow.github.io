%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Adjusting for Information Content when Comparing Forecast Performance
% Journal of Forecasting, 36, 784-794
%
% By: Andersson, Aranki & Reslow
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; close all; clc

rng('default') % default seed for random number generator
Loop_spec

for s = 1:48; % s = 1:24 replicates the table in Andersson, Aranki & Reslow 2017
%% Spec
S = 100000;             % number of simulations

c = LOOP(s,1);          % Case: 1 (A=...=G), 2 (A>...>G), 3 (A<...<G), 4 random
N = LOOP(s,2);          % years in ability sample
sigma = LOOP(s,3);      % std in error term
a = LOOP(s,4);          % "Own effekt" (persistence in data)

mu = 0.02;              % Ability signal 
Hmax = 24;              % monthly data = 24, quarterly = 8


%%
% Publishing calendar
H = [1 1 0 0 0 0 0;0 0 1 1 0 1 0;1 0 0 0 1 0 0;0 1 1 0 0 0 1;0 0 0 1 1 0 0;1 0 0 0 0 0 1;0 1 0 0 0 1 0;0 0 1 1 0 0 0;
     0 0 0 0 1 1 0;1 1 1 0 0 0 1;0 0 0 1 1 0 0;0 0 0 0 0 1 1;1 1 0 0 0 0 0;0 0 1 1 0 1 0;1 0 0 0 1 0 0;0 1 1 0 0 0 1;
     0 0 0 1 1 0 0;1 0 0 0 0 0 1;0 1 0 0 0 1 0;0 0 1 1 0 0 0;0 0 0 0 1 1 0;1 1 1 0 0 0 1;0 0 0 1 1 0 0;0 0 0 0 0 1 1];
H(H==0)= NaN;

% Individual ability
ind = 0:mu:mu*6; 
switch c
    case 1
        ind = 0*ind;        % Equal ability (A=...=G)
    case 2
        ind = fliplr(ind);  % A worst, G best, (A>...>G)
    case 3
        ind = ind;          % A best, G worst, (A<...<G)
    case 4
        gen_random;         % run random ability generator   
end
%%
% generate ref lines
[M, L] = get_ref2(Hmax, a);

for ii = 1:S
    if c == 4
        ind = Sind(ii,:);
    end
% draw forecast error
 for i = 1:N
    for j = 1:length(ind)
     for jj = 1:Hmax
      fe(jj,j,i) =  (L(jj) + ind(j) + abs(sigma*randn(1))) ;
     end
    end
    Ind_FE(:,:,i) = fe(:,:,i).*H ;
 end

for i = 1:N
    for j = 1:length(ind)
temp = Ind_FE(:,j,i);
temp = temp(~isnan(temp));
FE(:,j,i) = temp; 
    end
end

 % Calculate regulare MAE
temp = []; mae = [];
for i = 1:N   
temp = FE(:,:,i);
mae = [mae; temp];
end
MAE(ii,:) = mean(mae);

beta =  Est(FE,H,M);    % Estimate ability
B(:,ii) = beta;         % save
end

IND = B(N*2:end,:)' ; % take out ability from estimation

% for each simulation, rank individuals based on estimation and MAE
for i = 1:S
[~, idxA] = sort(IND(i,:)) ;
[~, idxB] = sort(MAE(i,:)) ; 
indexA(i,:) = idxA;
indexB(i,:) = idxB;
end

%%
% Get observed and expected frequency:
if c ==1
   for i = 1:7  
    O = hist(indexA(:,i),1:7);
    OA(i,:) = O; 
    E(i,:) = ones(1,7).*(S/7);
    Ob = hist(indexB(:,i),1:7);
    OB(i,:) = Ob;
   end
end

if c ==2
   for i = 1:7  
    O = hist(indexA(:,i),1:7);
    OA(i,:) = O; 
    E(i,:) = zeros(1,7);
    E(i,8-i) = S;
    Ob = hist(indexB(:,i),1:7);
    OB(i,:) = Ob;
   end
end

if c ==3
   for i = 1:7  
    O = hist(indexA(:,i),1:7);
    OA(i,:) = O; 
    E(i,:) = zeros(1,7);
    E(i,i) = S;
    Ob = hist(indexB(:,i),1:7);
    OB(i,:) = Ob;
   end
end

if c ==4
   for i = 1:7  
    O = hist(indexA(:,i),1:7);
    OA(i,:) = O; 
    Ob = hist(indexB(:,i),1:7);
    OB(i,:) = Ob;
    E(i,:) = hist(Erank(:,i),1:7);
   end
end


%% rho
if c == 1
    rho= zeros(7,7);
end

if c == 2
    for i = 1:7
        for r = 1:7
            j=8-i;
    rho(r,i) = abs(j-r);
        end
    end
end

if c == 3
    for i = 1:7
        for r = 1:7
    rho(r,i) = abs(i-r);
        end
    end
end

if c == 4
    rho= zeros(7,7);
end

%% MIR

MIR_a = sqrt(sum(sum(((OA - E).^2).*((1+rho).^2)))/49)/S;
MIR_b = sqrt(sum(sum(((OB - E).^2).*((1+rho).^2)))/49)/S;


save_loop(s,:) = [MIR_a MIR_b] ; % Table 2 (1:24)
save_figA(:,:,s) = OA/S; % Adjusted MAE figure 2
save_figB(:,:,s) = OB/S; % Unadjusted MAE figure 2

clearvars -except s LOOP save_loop save_figA save_figB

end